// Kosár elemek betöltése
function loadCartItems() {
    const cartContainer = document.getElementById('cartContainer');
    
    if (!cartContainer) {
        console.log('Kosár oldal nem található. A főoldalon nem futtatható.');
        return; // Kilépünk, ha nincs "cartContainer"
    }

    const cartItems = JSON.parse(localStorage.getItem('cart')) || [];

    if (cartItems.length === 0) {
        cartContainer.innerHTML = '<p>A kosár üres.</p>';
        return;
    }

    cartContainer.innerHTML = ''; // Kosár tartalmának törlése új betöltés előtt
    let totalPrice = 0;

    cartItems.forEach(item => {
        const itemRow = document.createElement('div');
        itemRow.classList.add('cart-item');
        itemRow.innerHTML = `
        <img src="../img/${item.image}" alt="${item.name}" class="cart-item-image">
        <div class="cart-item-details">
            <h3>${item.name}</h3>
            <p>Ár: ${item.price} Ft</p>
            <p>Mennyiség: ${item.quantity}</p>
        </div>
    `;
        cartContainer.appendChild(itemRow);
        totalPrice += item.price * item.quantity; // Összes ár számítása
    });

    const totalRow = document.createElement('div');
    totalRow.classList.add('cart-total');
    totalRow.innerHTML = `<h3>Összesen: ${totalPrice} Ft</h3>`;
    cartContainer.appendChild(totalRow);

    // Törlés és fizetés gombok hozzáadása
    const actionsRow = document.createElement('div');
    actionsRow.classList.add('cart-actions');
    actionsRow.innerHTML = `
        <button class="clear-cart">A kosár törlése</button>
        <button class="checkout">Tovább a fizetésre</button>
    `;
    cartContainer.appendChild(actionsRow);

    // Gombokhoz eseménykezelők hozzárendelése
    document.querySelector('.clear-cart').addEventListener('click', clearCart);
    document.querySelector('.checkout').addEventListener('click', checkout);
}

// Kosár törlése
function clearCart() {
    localStorage.removeItem('cart'); // Kosár ürítése
    loadCartItems(); // Kosár újratöltése
    alert('A kosár tartalma törölve.');
}

// Fizetés funkció
function checkout() {
    const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
    if (cartItems.length === 0) {
        alert('A kosár üres, nincs mit fizetni!');
        return;
    }
    alert('Fizetés sikeres! Köszönjük a vásárlást.');
    localStorage.removeItem('cart'); // Kosár törlése fizetés után
    loadCartItems(); // Kosár újratöltése
}

// Kosár frissítése az ikonon
function updateCart() {
    const cartCount = document.getElementById('cartCount');
    if (cartCount) {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
    }
}

// Hozzáadás a kosárhoz logika
function addToCart(event) {
    const button = event.target;
    const name = button.getAttribute('data-name');
    const price = parseInt(button.getAttribute('data-price'));
    const image = button.getAttribute('data-image').split('/').pop(); // Csak a fájlnév mentése

    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const existingProduct = cart.find(item => item.name === name);

    if (existingProduct) {
        existingProduct.quantity++; // Ha már létezik, növeljük a mennyiséget
    } else {
        cart.push({ name, price, image, quantity: 1 }); // Új termék hozzáadása
    }

    localStorage.setItem('cart', JSON.stringify(cart)); // Kosár mentése a LocalStorage-ba
    updateCart(); // Kosár frissítése
    alert(`${name} hozzáadva a kosárhoz.`);
}

// Gombok eseménykezelése
document.addEventListener('DOMContentLoaded', () => {
    const addButtons = document.querySelectorAll('.add-to-cart');
    addButtons.forEach(button => {
        button.addEventListener('click', addToCart); // Hozzáadás a kosárhoz
    });
    
    // Ha a kosár oldal van, töltsük be a kosarat
    if (document.getElementById('cartContainer')) {
        loadCartItems();
        updateCart();
    }
});
